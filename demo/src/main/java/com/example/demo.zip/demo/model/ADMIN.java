package com.example.demo.model;


public class ADMIN {

    String name;
    String age;

}
